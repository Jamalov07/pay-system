-- AlterTable
ALTER TABLE "increment_wallet_number" ALTER COLUMN "num" SET DEFAULT '10000000000000000000';
