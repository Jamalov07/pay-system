-- AlterTable
ALTER TABLE "increment_card_number" ALTER COLUMN "num" SET DEFAULT '100000000000';

-- AlterTable
ALTER TABLE "increment_wallet_number" ALTER COLUMN "num" SET DEFAULT '100000000000000000';
