-- AlterTable
ALTER TABLE "payment_history" ADD COLUMN     "is_success" BOOLEAN NOT NULL DEFAULT false;
