import { Module } from '@nestjs/common'
import { BankModule, DatabaseModule, WalletModule, UserModule, CompanyModule } from './modules'
import { ConfigModule } from '@nestjs/config'
import { bankDbConfig, userDbConfig } from './configs'

@Module({
	imports: [ConfigModule.forRoot({ isGlobal: true, load: [userDbConfig, bankDbConfig] }), DatabaseModule, BankModule, WalletModule, UserModule, CompanyModule],
})
export class AppModule {}
