export declare interface DatabaseConfigOptions {
	url?: string
}
