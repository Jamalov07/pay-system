export declare interface AppConfig {
	port: number
	host: string
}
