import { CompanyRequired } from './company-fields.interfaces'

export declare type CompanyDeleteRequest = Pick<CompanyRequired, 'id'>
export declare type CompanyDeleteResponse = null
