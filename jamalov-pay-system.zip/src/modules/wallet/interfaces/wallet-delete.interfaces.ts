import { WalletRequeired } from './wallet-fields.interfaces'

export declare type WalletDeleteRequest = Pick<WalletRequeired, 'id'>

export declare type WalletDeleteResponse = null
