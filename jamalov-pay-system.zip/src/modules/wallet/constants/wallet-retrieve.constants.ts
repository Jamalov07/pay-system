export const PAGE_NUMBER = 1
export const PAGE_SIZE = 10
export const NUMBER = ''
