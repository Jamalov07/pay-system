export enum WalletType {
	card = 'card',
	accountNumber = 'accountNumber',
}
