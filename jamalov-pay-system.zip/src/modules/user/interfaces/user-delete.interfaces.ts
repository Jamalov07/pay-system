import { UserRequired } from './user-fields.interfaces'

export declare type UserDeleteRequest = Pick<UserRequired, 'id'>
export declare type UserDeleteResponse = null
