import { BankRequeired } from './bank-fields.interfaces'

export declare type BankDeleteRequest = Pick<BankRequeired, 'id'>

export declare type BankDeleteResponse = null
