export const PAGE_NUMBER = 1
export const PAGE_SIZE = 10
export const NAME = ''
export const IS_MAIN = false
export const ADDRESS = ''
export const CARD_STARTS = ''
